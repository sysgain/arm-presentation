Configuration dscconfig
{
    param(

        [Parameter(Mandatory=$true)]
        [string]
        $nodeName,

        [Parameter(Mandatory=$true)]
        [string]
        $sourcePath,

        [Parameter(Mandatory=$true)]
        [string]
        $adminUsername,

        [Parameter(Mandatory=$true)]
        [SecureString]
        $adminPassword
   
    )
    Set-ExecutionPolicy -NoProfile -ExecutionPolicy Unrestricted -Force 

    $pscreds = New-Object -TypeName PSCredential -ArgumentList $adminUsername, $adminPassword
    Install-Module xWebAdministration -Force -Credential $pscreds
    Install-Module xPSDesiredStateConfigurations -Force -Credential $pscreds
    Import-DscResource -ModuleName xWebAdministration 
    Import-DscResource -ModuleName xPSDesiredStateConfiguration 

    Node $nodeName{

        xRemoteFile DownloadFile
        {
            DestinationPath = "C:\site.zip"
            Uri = $sourcePath
        }

        Archive content {
            Path = "C:\site.zip"
            Destination = "C:\inetpub\"
            DependsOn = "[xRemoteFile]DownloadFile"
        } 

        WindowsFeature IIS{
            Ensure = "Present"
            Name = "Web-Server"
        }

        WindowsFeature AspNet45{
            Ensure = "Present"
            Name = "Web-Asp-Net45"
        }

        WindowsFeature WebServerManagementConsole
        {
            Ensure = "Present"
            Name = "Web-Mgmt-Console"
        }

        xWebsite DefaultSite 
        {
            Ensure          = 'Absent'
            Name            = 'Default Web Site'
            PhysicalPath    = 'C:\inetpub\wwwroot'
            DependsOn       = '[WindowsFeature]IIS'
        }

        # Copy the website content
       <# File WebContent
        {
            Ensure          = 'Present'
            SourcePath      = $sourcePath
            DestinationPath = $destinationPath
            Recurse         = $true
            Type            = 'Directory'
            DependsOn       = '[WindowsFeature]AspNet45'
        } #>      

        # Create the new Website
        xWebsite NewWebsite
        {
            Ensure          = "Present"
            Name            = "Lawfirm"
            State           = "Started"
            PhysicalPath    = "C:\inetpub\lawfirm"
            DefaultPage     = "index.html"
            DependsOn       = "[WindowsFeature]WebServerManagementConsole"
            BindingInfo     = MSFT_xWebBindingInformation
                              {
                                  Protocol = "HTTP"
                                  Port = 80
                              }
        }
    }
}
dscconfig -OutputPath "C:\temp\web"
Start-DscConfiguration -ComputerName $nodeName -Path "C:\temp\web" -Wait -Verbose -Force
