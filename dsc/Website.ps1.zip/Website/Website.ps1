Configuration Website
{
    param(

        [Parameter(Mandatory=$true)]
        [string]
        $nodeName,

        [Parameter(Mandatory=$true)]
        [string]
        $sourcePath

    )
    Set-ExecutionPolicy -ExecutionPolicy Unrestricted  -Force
    Import-DscResource -Module xWebAdministration

    Node $nodeName{
        WindowsFeature IIS{
            Ensure = "Present"
            Name = "Web-Server"
        }
        WindowsFeature AspNet45{
            Ensure = "Present"
            Name = "Web-Asp-Net45"
        }
        WindowsFeature WebServerManagementConsole
        {
            Ensure = "Present"
            Name = "Web-Mgmt-Console"
        }
        xWebsite DefaultSite 
        {
            Ensure          = "Absent"
            Name            = "Default Web Site"
            State           = "Stopped"        
            PhysicalPath    = "C:\inetpub\wwwroot"
            DependsOn       = "[WindowsFeature]IIS"
        }
        
        # Copy the website content
        File WebContent
        {
            Ensure          = "Present"
            SourcePath      = $sourcePath
            DestinationPath = "C:\inetpub\lawfirm\"
            Recurse         = $true
            Type            = "Directory"
            DependsOn       = "[WindowsFeature]AspNet45"
        }       

        # Create the new Website
        xWebsite NewWebsite
        {
            Ensure          = "Present"
            Name            = "Lawfirm"
            State           = "Started"
            PhysicalPath    = "C:\inetpub\lawfirm\"
            DefaultPage     = "index.html"
            DependsOn       = "[File]WebContent"
            BindingInfo     = MSFT_xWebBindingInformation
                              {
                                  Protocol = "HTTP"
                                  Port = 80
                              }
        }
    }
}

